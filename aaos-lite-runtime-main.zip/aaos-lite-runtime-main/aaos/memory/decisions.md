# Decisions

- Keep AAOS Lite local-first.
- Use mock model by default.
- Support OpenAI-compatible APIs.
