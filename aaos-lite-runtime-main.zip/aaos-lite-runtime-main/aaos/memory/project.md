# Project Memory

AAOS Lite is a local-first AI agent operating layer.
