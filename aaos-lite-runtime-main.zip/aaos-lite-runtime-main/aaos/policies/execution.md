# Execution Policy

Commands proposed by agents require human approval. All runs are logged under aaos/runs/.
