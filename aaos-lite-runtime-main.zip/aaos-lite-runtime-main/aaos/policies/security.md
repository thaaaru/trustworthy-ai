# Security Policy

Do not read secrets, modify .env files, delete systems, or access production without explicit approval.
