# AAOS Lite Runtime

AAOS Lite is a local-first starter runtime for affordable agentic software development.

It includes:
- Mission-control CLI
- Agent registry
- Workflow execution
- Policy loading
- Project memory loading
- Model routing
- Human approval gates
- Tool execution with safety controls
- OpenFANG adapter placeholder
- Run history

## Architecture

```text
Human -> Mission Control CLI -> AAOS Lite Core -> Workflow Runner -> Agents -> Model Router -> LLMs -> Tools
```

## Install

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run offline with mock model

```bash
python aaos.py doctor
python aaos.py agents
python aaos.py run "Build a simple vulnerability dashboard"
python aaos.py run-file examples/vulnerability-dashboard.task.md
```

## Use DeepSeek/OpenAI-compatible API

```bash
export AAOS_MODEL_PROVIDER=openai_compatible
export AAOS_MODEL_BASE_URL="https://api.deepseek.com"
export AAOS_MODEL_API_KEY="your-api-key"
export AAOS_MODEL_NAME="deepseek-chat"
python aaos.py run "Create a secure login module design"
```

## Safety Model

AAOS Lite blocks dangerous patterns and requires approval before executing commands proposed by agents.
