#!/usr/bin/env python3
from aaos_lite.cli import main
if __name__ == '__main__':
    main()
