from datetime import datetime
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from .agents import AgentRegistry
from .memory import MemoryStore
from .models import ModelRouter
from .policy import PolicyEngine
from .tools import ToolExecutor
from .workflow import Workflow
console=Console()
class AAOSRuntime:
    def __init__(self, cfg):
        self.cfg=cfg; self.agent_registry=AgentRegistry(); self.memory=MemoryStore()
        self.policy=PolicyEngine(blocked_patterns=cfg.get('execution',{}).get('blocked_patterns'))
        self.model_router=ModelRouter(cfg); self.workflow=Workflow()
        self.tool_executor=ToolExecutor(self.policy, approval_required=cfg.get('execution',{}).get('approval_required', True))
    def run(self, task):
        run_id=datetime.utcnow().strftime('%Y%m%d-%H%M%S'); run_dir=Path('aaos/runs')/run_id; run_dir.mkdir(parents=True, exist_ok=True)
        context=f"""MISSION:\n{self.cfg.get('mission')}\n\nTASK:\n{task}\n\nMEMORY:\n{self.memory.load()}\n\nPOLICIES:\n{self.policy.load()}\n"""
        console.print(Panel(task, title='AAOS Lite Task'))
        for step in self.workflow.steps:
            agent=self.agent_registry.get(step['agent']); console.print(Panel(agent.role, title=f'Agent: {agent.name}'))
            system=f"""You are the {agent.name} agent.\nROLE:\n{agent.role}\nINSTRUCTIONS:\n{agent.prompt}\nIf shell execution is needed, place commands after PROPOSED_COMMANDS:."""
            output=self.model_router.complete(system, context, agent_name=agent.name)
            console.print(output); (run_dir/f'{agent.name}.md').write_text(output, encoding='utf-8')
            commands=self.tool_executor.extract_commands(output)
            if step.get('allow_tools', False) and commands: self.tool_executor.run_commands(commands)
            context += f'\n\nOUTPUT FROM {agent.name}:\n{output}\n'
        (run_dir/'task.md').write_text(task, encoding='utf-8')
        console.print(f'[green]Run saved:[/green] {run_dir}')
