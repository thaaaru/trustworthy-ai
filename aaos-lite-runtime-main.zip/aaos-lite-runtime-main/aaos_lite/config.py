import os
from pathlib import Path
import yaml
CONFIG_PATH = Path('aaos/config.yaml')
def load_config():
    data = yaml.safe_load(CONFIG_PATH.read_text(encoding='utf-8'))
    mapping = {
        'AAOS_MODEL_PROVIDER': ('model','provider'),
        'AAOS_MODEL_BASE_URL': ('model','base_url'),
        'AAOS_MODEL_API_KEY': ('model','api_key'),
        'AAOS_MODEL_NAME': ('model','name'),
    }
    for env, (section, key) in mapping.items():
        if os.getenv(env): data.setdefault(section,{})[key] = os.getenv(env)
    return data
