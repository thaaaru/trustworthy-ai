import requests
class ModelRouter:
    def __init__(self, cfg): self.cfg = cfg.get('model', {'provider':'mock','name':'mock'})
    def complete(self, system, user, agent_name='agent'):
        provider=self.cfg.get('provider','mock')
        if provider == 'mock': return self._mock_response(agent_name)
        if provider == 'openai_compatible': return self._openai_compatible(system, user)
        raise ValueError(f'Unsupported provider: {provider}')
    def _mock_response(self, agent_name):
        responses={
            'architect':'ARCHITECTURE PLAN\n- Define scope and acceptance criteria.\n- Create minimal app structure.\n- Keep security controls explicit.\n- Pass implementation tasks to developer.',
            'developer':'IMPLEMENTATION PLAN\n- Create files under workspace/app.\n- Avoid secrets in source.\nPROPOSED_COMMANDS:\nmkdir -p workspace/app\necho "# Generated App" > workspace/app/README.md\necho "Generated through AAOS Lite workflow." >> workspace/app/README.md',
            'tester':'TEST PLAN\n- Check generated README exists.\nPROPOSED_COMMANDS:\ntest -f workspace/app/README.md',
            'security':'SECURITY REVIEW\n- No destructive commands detected in proposed flow.\n- No credential handling detected.\n- Approval gate remains mandatory.'
        }
        return responses.get(agent_name, 'Mock model response.')
    def _openai_compatible(self, system, user):
        base_url=self.cfg['base_url'].rstrip('/'); api_key=self.cfg['api_key']; model=self.cfg['name']
        resp=requests.post(f'{base_url}/v1/chat/completions', headers={'Authorization':f'Bearer {api_key}','Content-Type':'application/json'}, json={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':user}], 'temperature':0.2}, timeout=90)
        resp.raise_for_status(); return resp.json()['choices'][0]['message']['content']
