import subprocess
from rich.console import Console
console=Console()
class ToolExecutor:
    def __init__(self, policy_engine, approval_required=True):
        self.policy_engine=policy_engine; self.approval_required=approval_required
    def extract_commands(self, text):
        if 'PROPOSED_COMMANDS:' not in text: return []
        raw=text.split('PROPOSED_COMMANDS:',1)[1].strip()
        return [line for line in raw.splitlines() if line.strip()]
    def run_commands(self, commands):
        for command in commands:
            allowed, reason = self.policy_engine.validate_command(command)
            if not allowed:
                console.print(f'[red]Blocked:[/red] {command}\n{reason}'); continue
            console.print(f'[yellow]Proposed command:[/yellow] {command}')
            if self.approval_required:
                answer=input('Approve execution? [y/N] ').strip().lower()
                if answer!='y': console.print('[dim]Skipped.[/dim]'); continue
            result=subprocess.run(command, shell=True, text=True, capture_output=True)
            if result.stdout: console.print(result.stdout)
            if result.stderr: console.print(f'[red]{result.stderr}[/red]')
