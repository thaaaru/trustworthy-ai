from pathlib import Path
class MemoryStore:
    def __init__(self, memory_dir='aaos/memory'):
        self.memory_dir = Path(memory_dir)
    def load(self):
        parts=[]
        for path in sorted(self.memory_dir.glob('*.md')):
            parts.append(f'## Memory: {path.name}\n{path.read_text(encoding="utf-8")}')
        return '\n\n'.join(parts)
    def append_decision(self, text):
        with (self.memory_dir/'decisions.md').open('a', encoding='utf-8') as f: f.write(f'\n\n- {text}\n')
