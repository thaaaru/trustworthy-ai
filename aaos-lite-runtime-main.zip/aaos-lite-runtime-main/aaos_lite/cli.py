import argparse
from pathlib import Path
from rich.console import Console
from rich.table import Table
from .config import load_config
from .runtime import AAOSRuntime
console = Console()

def main():
    parser = argparse.ArgumentParser(description='AAOS Lite - local agent operating layer')
    sub = parser.add_subparsers(dest='cmd')
    sub.add_parser('doctor', help='Show runtime configuration')
    sub.add_parser('agents', help='List registered agents')
    run = sub.add_parser('run', help='Run a task')
    run.add_argument('task')
    run_file = sub.add_parser('run-file', help='Run a task from a markdown file')
    run_file.add_argument('path')
    args = parser.parse_args()
    cfg = load_config()
    if args.cmd == 'doctor':
        table = Table(title='AAOS Lite Doctor')
        table.add_column('Key'); table.add_column('Value')
        table.add_row('Mission', cfg.get('mission',''))
        table.add_row('Provider', cfg.get('model',{}).get('provider','mock'))
        table.add_row('Model', cfg.get('model',{}).get('name','mock'))
        table.add_row('Approval Required', str(cfg.get('execution',{}).get('approval_required', True)))
        console.print(table); return
    runtime = AAOSRuntime(cfg)
    if args.cmd == 'agents':
        table = Table(title='Registered Agents')
        table.add_column('Agent'); table.add_column('Role'); table.add_column('Model')
        for agent in runtime.agent_registry.agents.values(): table.add_row(agent.name, agent.role, agent.model)
        console.print(table); return
    if args.cmd == 'run': runtime.run(args.task); return
    if args.cmd == 'run-file': runtime.run(Path(args.path).read_text(encoding='utf-8')); return
    parser.print_help()
