from dataclasses import dataclass
from pathlib import Path
import yaml
@dataclass
class Agent:
    name: str; role: str; model: str; prompt: str
class AgentRegistry:
    def __init__(self, agents_dir='aaos/agents'):
        self.agents_dir=Path(agents_dir); self.agents=self._load_agents()
    def _load_agents(self):
        agents={}
        for path in sorted(self.agents_dir.glob('*.yaml')):
            data=yaml.safe_load(path.read_text(encoding='utf-8'))
            agent=Agent(data['name'], data['role'], data.get('model','default'), data['prompt'])
            agents[agent.name]=agent
        return agents
    def get(self, name): return self.agents[name]
