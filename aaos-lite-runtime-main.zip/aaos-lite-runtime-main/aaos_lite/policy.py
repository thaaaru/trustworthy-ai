from pathlib import Path
class PolicyEngine:
    def __init__(self, policy_dir='aaos/policies', blocked_patterns=None):
        self.policy_dir = Path(policy_dir)
        self.blocked_patterns = blocked_patterns or ['rm -rf','terraform destroy','kubectl delete','DROP DATABASE','>.env',' .env','/etc/passwd','/etc/shadow']
    def load(self):
        parts=[]
        for path in sorted(self.policy_dir.glob('*.md')):
            parts.append(f'## Policy: {path.name}\n{path.read_text(encoding="utf-8")}')
        return '\n\n'.join(parts)
    def validate_command(self, command):
        hits=[p for p in self.blocked_patterns if p.lower() in command.lower()]
        if hits: return False, 'Blocked by policy: '+', '.join(hits)
        return True, 'Allowed'
