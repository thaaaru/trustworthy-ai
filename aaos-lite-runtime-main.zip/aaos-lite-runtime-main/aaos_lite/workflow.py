from pathlib import Path
import yaml
class Workflow:
    def __init__(self, path='aaos/workflows/build-feature.yaml'):
        self.path=Path(path); self.data=yaml.safe_load(self.path.read_text(encoding='utf-8'))
    @property
    def steps(self): return self.data['steps']
