# Architecture Decision

## Context

<!-- Problem and relevant constraints -->

## Proposed design

<!-- Components, interfaces, data flow and trust boundaries -->

## Alternatives considered

<!-- At least one credible alternative and why it was rejected -->

## Consequences

<!-- Benefits, costs, operational impact and residual risk -->

## Decision owner

- Owner:
- Date:

