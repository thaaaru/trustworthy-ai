# Retrospective

## Outcome against acceptance criteria

## Incidents, defects or surprises

## Evidence and metrics

## Decisions to retain or reverse

## Owned follow-up actions

