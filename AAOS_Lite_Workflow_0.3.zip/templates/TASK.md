# Engagement Contract

Contract-Version: 1
Task-ID: PROJECT-001
Owner: PRODUCT-OWNER
Risk-Tier: MEDIUM

## Purpose

[Why this work is needed]

## Requested outcome

[Observable outcome, not an implementation guess]

## In scope

- [Explicit target]

## Out of scope

- Production systems
- Credentials and secrets
- Network access
- Destructive or irreversible actions

## Approved workspace

This Git repository and the feature branch created for this task.

## Stakeholders

- Owner: [name or role]
- Approver: [name or role]
- Affected users: [group]

## Acceptance criteria

- AC-01: [measurable outcome]
- AC-02: [measurable security or quality condition]
- AC-03: All actions and evidence are traceable to this Task-ID.

## Constraints

- Execute only the commands allow-listed in `workflow.json` unless a human explicitly authorizes another command.
- Do not expose credentials or production data to the agent.
- Do not modify files outside this repository.

## Assumptions requiring validation

- [Assumption]

## Human confirmation

Status: DRAFT
Confirmed-By: NONE
Confirmed-At: NONE
