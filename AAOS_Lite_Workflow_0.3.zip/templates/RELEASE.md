# Release Record

- Version / commit:
- Target environment:
- Release owner:
- Approved change window:
- Deployment procedure:
- Smoke test:
- Rollback trigger:
- Rollback procedure:
- Observation period and owner:

