# Threat and Abuse Review

| Asset or boundary | Threat / failure | Preventive control | Verification | Residual risk | Owner |
|---|---|---|---|---|---|
| | | | | | |

## Security acceptance criteria

- [ ] Authorization is enforced server-side.
- [ ] Inputs are validated at trust boundaries.
- [ ] Secrets and sensitive data are not logged.
- [ ] Failure behaviour is safe and observable.

