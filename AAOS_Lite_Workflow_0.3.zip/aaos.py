#!/usr/bin/env python3
"""Deterministic workflow controller for AAOS Lite."""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DIR = ROOT / ".aaos"
STATE = DIR / "STATE.json"
CONFIG = ROOT / "workflow.json"
LOG = DIR / "RUN_LOG.jsonl"
APPROVALS = DIR / "APPROVALS.jsonl"
EVIDENCE = DIR / "evidence"

def now(): return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()

def read(path):
    try: return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc: raise SystemExit(f"ERROR: cannot read {path}: {exc}")

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)

def append(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as out: out.write(json.dumps(value, sort_keys=True) + "\n")

def cfg():
    value = read(CONFIG)
    if value.get("initial_state") not in value.get("states", []): raise SystemExit("ERROR: invalid workflow.json")
    return value

def current():
    if not STATE.exists(): raise SystemExit("ERROR: run: python aaos.py init")
    value = read(STATE)
    if value.get("state") not in cfg()["states"]: raise SystemExit("ERROR: invalid workflow state")
    return value

def gate(config, value):
    result = config.get("transitions", {}).get(value["state"])
    if not result: raise SystemExit(f"ERROR: {value['state']} is terminal")
    return result

def required(rule): return [DIR / name for name in rule.get("required_files", [])]

def evidence_files(value):
    return [ROOT / item["path"] for item in value.get("evidence", []) if (ROOT / item["path"]).is_file()]

def digest(paths):
    value = hashlib.sha256()
    for path in sorted(paths):
        value.update(str(path.relative_to(ROOT)).encode())
        value.update(path.read_bytes())
    return value.hexdigest()

def validate(config, value):
    rule, errors = gate(config, value), []
    for path in required(rule):
        if not path.is_file() or not path.read_text(encoding="utf-8").strip(): errors.append(f"missing/empty: {path.relative_to(ROOT)}")
    passed = {item["name"] for item in value.get("evidence", []) if item.get("status") == "PASS"}
    for name in rule.get("checks", []):
        if name not in passed: errors.append(f"check not passed: {name}")
    if rule.get("approval"):
        approval = value.get("approval")
        if not approval or approval.get("decision") != "approve": errors.append(f"approval required: {value['state']}")
        elif approval.get("evidence_digest") != digest(required(rule) + evidence_files(value)): errors.append("approval stale: controlled evidence changed")
    return errors

def init(_):
    if STATE.exists(): raise SystemExit("ERROR: already initialized")
    EVIDENCE.mkdir(parents=True)
    for name in ("TASK.md", "ARCHITECTURE.md", "THREATS.md", "EVIDENCE.md", "RELEASE.md", "RETROSPECTIVE.md"):
        source = ROOT / "templates" / name
        (DIR / name).write_text(source.read_text(encoding="utf-8"), encoding="utf-8")
    config = cfg()
    value = {"workflow_version": config["version"], "state": config["initial_state"], "attempts": {}, "evidence": [], "approval": None, "updated_at": now()}
    write(STATE, value); append(LOG, {"at": now(), "event": "INITIALIZED", "state": value["state"]})
    print(f"Initialized at {value['state']}")

def status(_):
    config, value = cfg(), current(); rule = config.get("transitions", {}).get(value["state"], {})
    print(json.dumps({"state": value["state"], "next": rule.get("next"), "approval_required": rule.get("approval", False), "required_checks": rule.get("checks", []), "evidence": value.get("evidence", [])}, indent=2))

def check_gate(_):
    errors = validate(cfg(), current())
    if errors:
        print("\n".join(f"FAIL: {item}" for item in errors)); raise SystemExit(1)
    print("PASS: gate requirements satisfied")

def run_checks(_):
    config, value = cfg(), current(); names = gate(config, value).get("checks", [])
    if not names: raise SystemExit(f"ERROR: no checks configured for {value['state']}")
    value["approval"] = None
    value["evidence"] = [item for item in value.get("evidence", []) if item.get("name") not in names]
    failed = False
    for name in names:
        spec = config["checks"][name]; attempts = value.setdefault("attempts", {})
        attempts[name] = attempts.get(name, 0) + 1
        if attempts[name] > config["max_check_attempts"]:
            print(f"FAIL: {name} retry limit exceeded"); failed = True; continue
        try:
            result = subprocess.run(spec["command"], cwd=ROOT, capture_output=True, text=True, timeout=spec.get("timeout_seconds", 120), shell=False)
            passed = result.returncode in spec.get("pass_exit_codes", [0]); output = result.stdout + result.stderr; code = result.returncode
        except subprocess.TimeoutExpired as exc: passed, output, code = False, str(exc), -1
        outcome = "PASS" if passed else "FAIL"; artifact = EVIDENCE / f"{value['state'].lower()}-{name}-{attempts[name]}.txt"
        artifact.write_text(f"check: {name}\nstatus: {outcome}\nexit_code: {code}\ncommand: {json.dumps(spec['command'])}\n\n{output[-100000:]}", encoding="utf-8")
        item = {"name": name, "status": outcome, "path": str(artifact.relative_to(ROOT)), "sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(), "at": now()}
        value["evidence"].append(item); append(LOG, {"event": "CHECK", "state": value["state"], **item}); print(f"{outcome}: {name}")
        failed |= not passed
    value["updated_at"] = now(); write(STATE, value)
    if failed: raise SystemExit(1)

def approve(args):
    config, value = cfg(), current(); rule = gate(config, value)
    if not rule.get("approval"): raise SystemExit(f"ERROR: approval not required at {value['state']}")
    record = {"state": value["state"], "decision": args.decision, "by": args.by, "note": args.note, "at": now(), "evidence_digest": digest(required(rule) + evidence_files(value))}
    value["approval"] = record; value["updated_at"] = now(); write(STATE, value); append(APPROVALS, record); append(LOG, {"event": "APPROVAL", **record})
    print(f"Recorded {args.decision} for {value['state']} by {args.by}")

def advance(_):
    config, value = cfg(), current(); rule = gate(config, value); errors = validate(config, value)
    if errors:
        print("\n".join(f"BLOCKED: {item}" for item in errors)); raise SystemExit(1)
    before, after = value["state"], rule["next"]
    value.update({"state": after, "approval": None, "evidence": [], "attempts": {}, "updated_at": now()}); write(STATE, value)
    append(LOG, {"at": now(), "event": "TRANSITION", "from": before, "to": after}); print(f"Advanced: {before} -> {after}")

def recover(args):
    value = current()
    if value["state"] not in {"ASSURE", "OPERATE"}: raise SystemExit("ERROR: recovery allowed only from ASSURE or OPERATE")
    before = value["state"]; value.update({"state": "ENGINEER", "approval": None, "evidence": [], "attempts": {}, "updated_at": now()}); write(STATE, value)
    append(LOG, {"at": now(), "event": "RECOVERY", "from": before, "to": "ENGINEER", "reason": args.reason}); print(f"Recovered: {before} -> ENGINEER")

def history(_): print(LOG.read_text(encoding="utf-8") if LOG.exists() else "No history")

def main():
    parser = argparse.ArgumentParser(); commands = parser.add_subparsers(required=True)
    for name, function in (("init", init), ("status", status), ("validate", check_gate), ("run-checks", run_checks), ("advance", advance), ("history", history)):
        commands.add_parser(name).set_defaults(func=function)
    item = commands.add_parser("approve"); item.add_argument("--by", required=True); item.add_argument("--decision", choices=["approve", "reject"], required=True); item.add_argument("--note", required=True); item.set_defaults(func=approve)
    item = commands.add_parser("recover"); item.add_argument("--reason", required=True); item.set_defaults(func=recover)
    args = parser.parse_args(); args.func(args)

if __name__ == "__main__": main()
