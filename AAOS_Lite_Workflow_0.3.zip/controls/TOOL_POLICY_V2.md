# Tool and Action Policy

## Default posture

Deny by default. The agent may use project tools required by the approved task, but automated assurance commands must be explicitly allow-listed as argument arrays in `workflow.json`.

| Capability | Default | Condition |
|---|---|---|
| Read repository files | Allowed | Within task scope |
| Create or modify feature code | Allowed at Engineer | Within approved paths and acceptance criteria |
| Run configured checks | Allowed at Assure | Invoke through `python aaos.py run-checks` |
| Install dependencies | Approval required | Lockfile change and source must be explicit |
| Network access | Approval required | Destination and data exposure must be known |
| Secrets | Denied to agent | Use CI/host secret injection only |
| Destructive operations | Approval required | Exact target and recovery method required |
| Production deployment | Human-only authorization | Release record and current approval required |

## Command safety

- Verification commands use `shell=False`; shell syntax and command chaining are not interpreted.
- Modify allow-listed commands only through reviewed changes to `workflow.json`.
- A command timeout, unexpected exit code or missing executable is a failed check.
- Never convert model-generated text directly into an executable command.

## Approval integrity

The controller hashes the gate's required files and evidence. Any later change invalidates the approval. Repository protection is still required because local files and the controller are not tamper-proof.
