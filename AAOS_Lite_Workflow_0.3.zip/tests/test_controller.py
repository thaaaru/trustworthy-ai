import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class WorkflowDefinitionTests(unittest.TestCase):
    def setUp(self):
        self.workflow = json.loads((ROOT / "workflow.json").read_text(encoding="utf-8"))

    def test_all_nonterminal_states_have_valid_next_state(self):
        states = set(self.workflow["states"])
        for state, transition in self.workflow["transitions"].items():
            self.assertIn(state, states)
            self.assertIn(transition["next"], states)

    def test_every_referenced_check_exists(self):
        checks = self.workflow["checks"]
        for transition in self.workflow["transitions"].values():
            for name in transition.get("checks", []): self.assertIn(name, checks)

    def test_commands_are_argument_arrays_not_shell_strings(self):
        for check in self.workflow["checks"].values():
            self.assertIsInstance(check["command"], list)
            self.assertTrue(check["command"])

    def test_assurance_requires_checks_and_approval(self):
        assurance = self.workflow["transitions"]["ASSURE"]
        self.assertTrue(assurance["approval"])
        self.assertGreaterEqual(len(assurance["checks"]), 3)

if __name__ == "__main__": unittest.main()

