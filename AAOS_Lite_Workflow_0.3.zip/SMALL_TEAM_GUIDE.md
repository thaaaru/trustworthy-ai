# Small-Team Operating Guide

## Roles

| Role | Responsibility |
|---|---|
| Task owner | Defines outcome, scope and acceptance criteria |
| Implementer / AI agent | Produces the bounded change and records assumptions |
| Reviewer | Reviews architecture, evidence and residual risk |
| Release owner | Authorizes deployment and owns rollback |

One person may hold several roles for a low-risk change. Separate implementer and assurance approver for changes affecting production, authentication, authorization, sensitive data, payments or destructive operations.

## Daily path

1. Initialize AAOS in a feature branch.
2. Complete `TASK.md`; approve the Understand gate.
3. Record the minimum architecture and threat decisions; approve Architect.
4. Implement only the accepted scope and advance to Assure.
5. Run deterministic checks. A failure blocks progression.
6. Review captured evidence and approve Assure.
7. Record release and rollback information; approve Operate immediately before deployment.
8. Observe, capture learning and close.

## Tailoring checks

Edit only `workflow.json`. Commands are argument arrays and never execute through a shell. Examples:

```json
"frontend": {"command": ["npm", "test", "--", "--run"], "timeout_seconds": 180}
```

```json
"security": {"command": ["semgrep", "scan", "--config", "auto", "--error"], "timeout_seconds": 300}
```

Add the check name to `ASSURE.checks`. Commit changes to the workflow definition through code review.

## Definition of done

A task is not done because an agent reports completion. It is done only when the workflow reaches `CLOSED`, all required checks have passed, approvals are bound to unchanged evidence, the release outcome is observed, and remaining actions have named owners.
