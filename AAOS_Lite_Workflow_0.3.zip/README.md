# AAOS Lite Workflow

A repository-local control plane for AI-assisted software development. Markdown remains the human/agent interface; `aaos.py` deterministically controls lifecycle transitions, runs allow-listed verification commands, records evidence and requires human approval at consequential gates.

It is suitable for one developer or a small team in one Git repository. It is deliberately not a distributed workflow engine.

## Controlled lifecycle

`UNDERSTAND → ARCHITECT → ENGINEER → ASSURE → OPERATE → EVOLVE → CLOSED`

The controller provides fixed transitions, required artifacts, check execution, evidence capture, approvals bound to evidence, retry limits, recovery to engineering, an append-only workflow log and CI enforcement.

## Requirements

- Python 3.10+; standard library only
- Git
- Your project's own test/security tools

## Start

```bash
python aaos.py init
python aaos.py status
```

Complete `.aaos/TASK.md`, then run:

```bash
python aaos.py validate
python aaos.py approve --by "Reviewer" --decision approve --note "Scope accepted"
python aaos.py advance
```

At `ASSURE`:

```bash
python aaos.py run-checks
python aaos.py approve --by "Reviewer" --decision approve --note "Evidence reviewed"
python aaos.py advance
```

Use `python aaos.py recover --reason "Assurance failure"` to return from `ASSURE` or `OPERATE` to `ENGINEER`. Use `python aaos.py history` to inspect the ledger.

## Important paths

| Path | Purpose |
|---|---|
| `AAOS.md` | Agent constitution |
| `workflow.json` | States, gates and allow-listed checks |
| `aaos.py` | Deterministic workflow controller |
| `.aaos/STATE.json` | Machine-authoritative state |
| `.aaos/*.md` | Scope, design, risk, release and learning records |
| `.aaos/evidence/` | Captured verification outputs |
| `.github/workflows/aaos.yml` | Pull-request enforcement |

## Security boundary

This prevents accidental workflow progression; it is not a sandbox. Protect `AAOS.md`, `workflow.json`, `aaos.py` and the CI workflow with branch protection and CODEOWNERS. Keep production credentials and deployment authority outside the agent process.

For production-, security-, privacy- or financial-impacting changes, the implementer and `ASSURE → OPERATE` approver should be different people.

